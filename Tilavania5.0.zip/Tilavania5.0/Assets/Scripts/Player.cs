﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    [SerializeField] float runSpeed = 5f;
    Vector2 playerVelocity = new Vector2(movement * runSpeed, myRigidBody.velocity.y);

    Rigidbody2D myRigidBody;

    // Start is called before the first frame update
    void Start()
    {
           myRigidBody = GetComponent<Rigidbody2D> ();   
    }

    
    // Update is called once per frame

    void Update()
    {
        Run();
    }

    private void Run()
    {
          float movement = Input.GetAxis("Horizontal");

           Vector2 playerVelocity = new Vector2(movement, myRigidBody.velocity.y);
          myRigidBody.velocity = playerVelocity;
    }
}